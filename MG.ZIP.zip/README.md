# MG

鬼山人高控突破掃描自動化程式，使用 GitHub Actions 執行每日排程。
